### 基础数据
import flask
from flask import request
from flask import jsonify
import json
from ccx_scoreModel.basevar_model import *
server = flask.Flask(__name__)
@server.route('/ccxModel_D', methods=['post'])
def ccxModel_D():
    try:

        json_data = json.loads(request.data.decode())
        apply_score, score_a, score_b, score_c, score_d, score_e = score_D_compute(json_data)
        return jsonify(
            {'apply_score': apply_score, 'model_a': score_a, 'model_b': score_b, 'model_c': score_c, 'model_d': score_d,
             'model_e': score_e})
    except Exception as e:
        return jsonify({"code": 500, "msg": "计算失败", "error_msg": str(e)})



if __name__ == '__main__':
    server.run(debug=True, host='0.0.0.0', port=1031)  # processes 为可支持并发量


