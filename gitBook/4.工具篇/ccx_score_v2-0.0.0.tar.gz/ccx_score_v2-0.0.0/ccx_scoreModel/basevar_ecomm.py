import pandas as pd
import numpy as np
import os
from ccx_scoreModel.f_basevar import *
from ccx_scoreModel.other_score import other_score
from ccx_scoreModel.submodel_5 import *
from sklearn.externals import joblib
from ccx_scoreModel.log import ABS_log
import pickle
path = os.path.dirname(os.path.realpath(__file__))

with open('score_tran_pkl_v2/base_ecommscore_dict.pkl', 'rb') as f: ecomm_basescore_dict = pickle.load(f)
with open('score_tran_pkl/ecomm_basescore_final.pkl', 'rb') as f: ecomm_basescore_final_dict = pickle.load(f)

#### 加载模型
model_path = os.path.join(path, 'base_ecomm_model.model')
xgb_model = joblib.load(model_path)

model_path2 = os.path.join(path, 'base_model.model')
xgb_model2 = joblib.load(model_path2)

@ABS_log('ccxscore3')
def score_C_compute(json_data):
    df = pd.DataFrame(index=['id'])
    mob = json_data['mobile']
    cid = json_data['cid']
    if pd.notnull(json_data['ecomm_score']):

        df['score'] = json_data['ecomm_score']
    else:
        df['score'] = np.nan
    df['age'] = f_age(cid)  # 年龄
    df['gender'] = f_gender(cid)  # 性别

    df['issame_prov'] = f_2equal_addr(f_get_mobile_prov(mob), get_idno_prov(cid))  # 省份是否一致
    df['issame_city'] = f_2equal_addr(f_get_mobile_city(mob), get_idno_city(cid))  # 城市是否一致

    df3 = df[['age', 'gender', 'issame_prov', 'issame_city', 'score']]

    odd = list(map(lambda i: i / (1 - i), xgb_model.predict_proba(df3)[:, 1]))
    score_test = 600 - 40 / np.log(2) * np.log(odd[0])

    df_base = df[['age', 'gender', 'issame_prov', 'issame_city']]

    odd = list(map(lambda i: i / (1 - i), xgb_model2.predict_proba(df_base)[:, 1]))
    base_score = 600 - 40 / np.log(2) * np.log(odd[0])

    score_a = sub_basescore(base_score)
    score_b = sub_lvyuescore(json_data)
    score_c = sub_credit_score(json_data)
    score_d = sub_act_score(json_data)
    score_e = sub_soc_score(base_score, json_data)

    final_score = other_score(score_test,json_data,ecomm_basescore_dict,ecomm_basescore_final_dict)

    return round(final_score),round(score_a),round(score_b),round(score_c),round(score_d),round(score_e)
