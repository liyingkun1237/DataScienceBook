def score_add(x1,x2):
    '''

    :param x1: 映射后的模型分
    :param x2: 映射后的联动分
    :return: 叠加后的分数
    '''
    if x1>=705 and x2>=705: # 两者都是高分段
        score = max([x1,x2])
    elif x1>= 635 and x2>=635: # 两者都是中分段以上，并且至多有一个高分
        score = 0.5*(x1+x2)
    elif x1<635 and x2<635: # 两者都是低分段
        score = min([x1,x2])
    elif (x1<635 and x2>=635) or (x2<635 and x1>=635): # 两者有且仅有一个是低分段
        score = 0.5*min([x1,x2])+0.5*max([x1,x2])

    return score
