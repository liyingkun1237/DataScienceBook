import json
import pandas as pd

def IC_score(x):
    '''

    :param x:
    :return: 工商得分
    '''


    if pd.notnull(x['LEGAL_PERSON']):

        if x['LEGAL_PERSON'] == 1:  # 企业法人
            score_1 = 3
        elif x['LEGAL_PERSON'] == 2 or x['LEGAL_PERSON'] == 3:
            score_1 = 4
        elif x['LEGAL_PERSON'] > 3:
            score_1 = 5
        else:
            score_1 = 0
    else:
        score_1 = 0
    if pd.notnull(x['SHAREHOLDER']):

        if x['SHAREHOLDER'] == 1:  # 股东
            score_2 = 1
        elif x['SHAREHOLDER'] == 2 or x['SHAREHOLDER'] == 3:
            score_2 = 2
        elif x['SHAREHOLDER'] > 3:
            score_2 = 3
        else:
            score_2 = 0
    else:
        score_2 = 0
    if pd.notnull(x['SENIOR_MANAGER']):

        if x['SENIOR_MANAGER'] == 1:  # 高管
            score_3 = 1
        elif x['SENIOR_MANAGER'] == 2 or x['SENIOR_MANAGER'] == 3:
            score_3 = 2
        elif x['SENIOR_MANAGER'] > 3:
            score_3 = 3
        else:
            score_3 = 0

    else:
        score_3 = 0
    if pd.notnull(x['INVESTMENT']):

        if x['INVESTMENT'] < 10 and x['INVESTMENT']>0:  # 投资金额
            score_4 = 1
        elif x['INVESTMENT'] >= 10 and x['INVESTMENT'] < 50:
            score_4 = 2
        elif x['INVESTMENT'] >= 50 and x['INVESTMENT'] < 100:
            score_4 = 3
        elif x['INVESTMENT'] >= 100:
            score_4 = 5
        else:
            score_4 = 0
    else:
        score_4 =0

    score = score_1 + score_2 + score_3 + score_4
    return score

