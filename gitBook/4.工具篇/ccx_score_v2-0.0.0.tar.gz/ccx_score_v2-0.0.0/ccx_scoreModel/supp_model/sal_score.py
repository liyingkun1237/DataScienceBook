import pandas as pd
def get_score_salary(x):
    '''

    :param x:
    :return: salary_score
    '''
    if pd.notnull(x):
        if (x <= 5000) & (x > 0):
            score = 3
        elif (x > 5000) & (x <= 10000):
            score = 5
        elif x > 10000:
            score = 10
        else:
            score = 0
    else:
        score = 0
    return score
