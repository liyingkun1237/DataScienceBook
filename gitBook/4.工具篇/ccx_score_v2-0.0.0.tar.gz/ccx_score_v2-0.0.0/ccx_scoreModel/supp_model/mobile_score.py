import pandas as pd
def mobile_score(x):
    if pd.notnull(x):
        if x <= 6:
            score = -5
        elif (x>6) & (x <= 12):
            score = 2
        elif (x>12) & (x<=24):
            score = 3
        else:
            score = 5
    else:
        score = 0
    return score