import numpy as np


def car_level(data_car):
    '''

    :param : data_car_list
    :return: score
    '''
    score_set = []
    if data_car:
        for i in data_car:
            if any([k in i for k in ['奔驰', '宝马', '凯迪拉克', '奥迪']]):
                res = 3
            elif any([k in i for k in ['沃尔沃', '迈腾', '蒙迪欧', '帕萨特', '指南者', '雷克萨斯', '英菲尼迪','斯巴鲁']]):
                res = 2
            else:
                res = 1
            score_set.append(res)
        score = np.max(score_set)
    else:
        score = 0
    return score


def get_score_car(x):
    if x == 1:
        score = 5
    elif x == 2:
        score = 10
    elif x == 3:
        score = 20
    else:
        score = 0
    return score
