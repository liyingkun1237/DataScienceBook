import pandas as pd
def flight_times(x):
    '''

    :param x:
    :return: 飞行次数评分
    '''
    if pd.notnull(x['flight_Times']):
        if x['flight_Times'] == 0 or x['flight_Times'] == 1:
            score_A_1 = 2
        elif x['flight_Times'] == 2 or x['flight_Times'] == 3:
            score_A_1 = 5
        elif x['flight_Times'] > 3:
            score_A_1 = 10
        else:
            score_A_1 = 0
    else:
        score_A_1 = 0
    return score_A_1


def flight_price(x):
    '''

    :param x:
    :return: 平均价格评分
    '''
    if pd.notnull(x['average_Price']):

        if x['average_Price'] == 0:
            score_A_2 = 1
        elif x['average_Price'] == 1 or x['average_Price'] == 2:
            score_A_2 = 2
        elif x['average_Price'] >= 3:
            score_A_2 = 3
        else:
            score_A_2 = 0
    else:
        score_A_2 = 0
    return score_A_2


def flight_discount(x):
    '''

    :param x:
    :return: 飞行折扣评分
    '''
    if pd.notnull(x['average_Discount']):

        if x['average_Discount'] == 0:
            score_A_3 = 1
        elif x['average_Discount'] == 1:
            score_A_3 = 2
        elif x['average_Discount'] == 2:
            score_A_3 = 3
        else:
            score_A_3 = 0
    else:
        score_A_3 = 0
    return score_A_3


#####################################################
def flight_info2(x):
    if x:
        if x['isChengJi']:
            if x['isGaoCang'] == 1:
                score_1 = 5
            elif x['isGaoCang'] == 0:
                score_1 = 2
            else:
                score_1 = 1

            if x['isGuoJi'] == 1:
                score_2 = 2
            else:
                score_2 = 0
            score = score_1 + score_2
        else:
            score = 0
    else:
        score = 0

    return score


############################################
def score_flight(fly_field):

    score_A = fly_field[0]
    res_p1 = flight_times(score_A) + flight_price(score_A) + flight_discount(score_A)
    score_B = fly_field[1]
    res_p2 = flight_info2(score_B)
    res = max([res_p1,res_p2])
    return res