from ccx_scoreModel.supp_model.car_score import *
from ccx_scoreModel.supp_model.flyscore import *
from ccx_scoreModel.supp_model.IC_score import *
from ccx_scoreModel.supp_model.mobile_score import *
from ccx_scoreModel.supp_model.sal_score import *
from ccx_scoreModel.double_score_add import *
import pickle
import pandas as pd

with open('score_tran_pkl/ump_dict.pkl', 'rb') as f: ump_score_tranf = pickle.load(f)

def other_score(apply_score, json_data, data_dict,data_final_dict):
    supp_score = get_score_car(car_level(json_data['carbrand'])) + get_score_salary(json_data['predict_salary']) + \
                 score_flight(json_data['airscore']) + mobile_score(json_data['mobile_net_time']) + IC_score(json_data['IC_info'])
    supp_score = 30 if supp_score > 30 else int(supp_score)  # supp_score 超过30分的算30
    second_score = apply_score + supp_score  # 模型分叠加supp分
    # print ('second_score:'+ str(second_score))
    second_score = 900 if second_score > 900 else int(second_score)  # second_score 超过900分的算900
    score_tranf = data_dict[int(second_score)]  # 分数映射

    ump_score_data = json_data['ump_score']
    if pd.notnull(ump_score_data) and ump_score_data > 600:  # 查得联动分，并且联动分超过600
        ump_score = ump_score_tranf[json_data['ump_score']]  # 联动分进行映射 # 20% 635 80% 705
        third_score = score_add(score_tranf, ump_score)  # 叠加second_score and ump_score
        # third_score = data_final_dict[int(third_score)]
        third_score = int(third_score)
    elif pd.notnull(ump_score_data) and ump_score_data <= 600 and ump_score_data!=-99:  # 查得联动分，并且联动分低于600
        third_score = ump_score_data - 100
    else:
        third_score = score_tranf
    # print (third_score)
    risk_part_raw = json_data['risk_score']  # 风险分part1
    # if risk_part_raw <= 30:
    #     risk_part1 = -risk_part_raw * 3
    # elif risk_part_raw > 30 and risk_part_raw <= 60:
    #     risk_part1 = -risk_part_raw * 4
    # elif risk_part_raw > 60:
    #     risk_part1 = -risk_part_raw * 5
    # else:
    #     risk_part1 = 0
    # risk_part2 = json_data['risk_score_other']  # 风险分part2
    if pd.isnull(risk_part_raw):
        risk_part_raw = 0
    final_score = third_score + risk_part_raw
    final_score = 300 if final_score < 300 else int(final_score)
    final_score = 900 if final_score > 900 else int(final_score)

    return final_score
