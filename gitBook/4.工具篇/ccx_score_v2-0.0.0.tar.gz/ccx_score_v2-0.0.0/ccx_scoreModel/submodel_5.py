from ccx_scoreModel.supp_model.car_score import *
from ccx_scoreModel.supp_model.flyscore import *
from ccx_scoreModel.supp_model.IC_score import *
from ccx_scoreModel.supp_model.mobile_score import *
from ccx_scoreModel.supp_model.sal_score import *
import pandas as pd


def sub_basescore(base_score):
    '''

    :param base_score:
    :return: 映射后的身份属性分
    '''
    return ((base_score - 500) / (900 - 500)) * 50 + 50


def sub_lvyuescore(json_data):
    '''

    :param json_data:
    :return: 映射后的履约分
    '''
    ump_score = json_data['ump_score']
    supp_score = get_score_car(car_level(json_data['carbrand'])) + get_score_salary(
        json_data['predict_salary']) + score_flight(json_data['airscore']) + IC_score(json_data['IC_info'])

    supp_score = 30 if supp_score > 30 else supp_score
    if ump_score:
        score = ump_score * 0.1 + supp_score
    else:
        score = 710 * 0.1 + supp_score

    score = ((score - 50) / (120 - 50)) * 50 + 50

    return score


def sub_credit_score(json_data):
    '''

    :param json_data:
    :return: 映射后的信用记录分
    '''
    ump_score = json_data['ump_score']
    risk_part_raw = json_data['risk_score']  # 风险分part1 0-100
    if pd.isnull(risk_part_raw):
        risk_part_raw = 0
    # if risk_part_raw <= 30:
    #     risk_part1 = -risk_part_raw * 3
    # elif risk_part_raw > 30 and risk_part_raw <= 60:
    #     risk_part1 = -risk_part_raw * 4
    # elif risk_part_raw > 60:
    #     risk_part1 = -risk_part_raw * 5
    # else:
    #     risk_part1 = 0
# max 5 min -100
    supp_score = mobile_score(json_data['mobile_net_time']) + risk_part_raw #+ json_data['risk_score_other']

    supp_score = -100 if supp_score < -100 else supp_score
    if ump_score:
        score = ump_score * 0.2 + supp_score
    else:
        score = 710 * 0.2 + supp_score
    score = ((score - 0) / (185 - 0)) * 50 + 50

    return score


def sub_act_score(json_data):
    '''

    :param json_data:
    :return: 行为特质分
    '''
    ecomm_score = json_data['ecomm_score'] # 0 代表查询但未查得 null代表查得

    ump_score = json_data['ump_score']
    if pd.notnull(ecomm_score) and ecomm_score!=0 and pd.isnull(ump_score):  # 查得电商，但没查得联动分
        score = (ecomm_score - 600) / 100 * 50 + 50
        score = 50 if score < 50 else score
        score = 100 if score > 100 else  score
    elif ecomm_score and ump_score:  # 查得电商分和联动分
        score = (ecomm_score + ump_score) * 0.1
        score = (score - 100) / 80 * 50 + 50
    elif (pd.isnull(ecomm_score) or ecomm_score ==0) and ump_score:  # 查得联动分，但未查得电商分
        score = (ump_score + 670) * 0.1
        score = (score - 117) / 40 * 50 + 50
    elif (pd.isnull(ecomm_score) or ecomm_score ==0) and pd.isnull(ump_score):  # 联动分和电商分都未查得
        score = (710 + 670) * 0.1
        score = (score - 100) / 80 * 50 + 50
    return score


def sub_soc_score(base_score, json_data):
    '''

    :param base_score:
    :param json_data:
    :return: 社交影响分
    '''
    # max 106 min 50
    score = base_score * 0.1 + IC_score(json_data['IC_info'])
    score = (score - 50) / 56 * 50 + 50
    return score
