import pandas as pd
import numpy as np
import os
from ccx_scoreModel.f_basevar import *
from sklearn.externals import joblib
from ccx_scoreModel.log import ABS_log
from ccx_scoreModel.other_score import other_score
from ccx_scoreModel.submodel_5 import *

path = os.path.dirname(os.path.realpath(__file__))

import pickle
with open('score_tran_pkl_v2/edu_ecomm_dict.pkl', 'rb') as f: Tscore_dict = pickle.load(f)
with open('score_tran_pkl/Tscore_final.pkl','rb') as f: Tscore_final_dict = pickle.load(f)
#### 加载模型
model_path = os.path.join(path, 'base_edu_ecomm_model.model')  # 基础字段+学历+电商分模型
xgb_model = joblib.load(model_path)
model_path2 = os.path.join(path, 'base_edu_model.model')  # 基础字段+学历模型
xgb_model2 = joblib.load(model_path2)

@ABS_log('ccxscore2')
def score_B_compute(json_data):
    df = pd.DataFrame(index=['id'])
    mob = json_data['mobile']
    cid = json_data['cid']
    if json_data['ecomm_score']:
        df['score'] = json_data['ecomm_score']
    else:
        df['score'] = np.nan

    df['age'] = f_age(cid)  # 年龄
    df['gender'] = f_gender(cid)  # 性别
    df['issame_prov'] = f_2equal_addr(f_get_mobile_prov(mob), get_idno_prov(cid))  # 省份是否一致
    df['issame_city'] = f_2equal_addr(f_get_mobile_city(mob), get_idno_city(cid))  # 城市是否一致
    df['birthY'] = f_birthyear(cid) #出生年份
    df['edu_degree'] = json_data['edu_degree']  # 学历等级
    if (pd.notnull(json_data['graduate_Y']))&(json_data['graduate_Y']!=-99):
        df['graduate_Y'] = json_data['graduate_Y']  # 毕业年限
    else:
        df['graduate_Y'] = np.nan


    df['school_star'] = json_data['school_star']  # 学校星级


    # 目前接口中没有下述两个字段
    df['grad_type'] = json_data['grad_type']  # 毕业结论，1:毕业, 2:结业
    df['edu_type'] = json_data['edu_type']  # 学历类型

    #onehot处理
    edu_onehot_var(df)  # 直接在df中增加了onehot后的字段

    edu_list = ['grad_type_1', 'edu_type_2', 'edu_degree_2','edu_degree_3']
    now_columns = df.columns
    for i in edu_list:
        df[i] = 0
        if i in now_columns:
            df[i] = 1

    df3 = df[['age','score', 'graduate_Y', 'gender', 'issame_city', 'issame_prov', 'school_star',
              'grad_type_1', 'edu_type_2', 'edu_degree_2']]

    odd = list(map(lambda i: i / (1 - i), xgb_model.predict_proba(df3)[:, 1]))
    score_test = 600 - 40 / np.log(2) * np.log(odd[0])

    df_base = df[['age', 'graduate_Y', 'issame_city', 'gender', 'issame_prov', 'grad_type_1', 'school_star',
                  'edu_type_2', 'edu_degree_2', 'edu_degree_3']]

    odd = list(map(lambda i: i / (1 - i), xgb_model2.predict_proba(df_base)[:, 1]))
    base_score = 600 - 40 / np.log(2) * np.log(odd[0])

    final_score = other_score(score_test,json_data,Tscore_dict,Tscore_final_dict)

    score_a = sub_basescore(base_score)
    score_b = sub_lvyuescore(json_data)
    score_c = sub_credit_score(json_data)
    score_d = sub_act_score(json_data)
    score_e = sub_soc_score(base_score,json_data)
    return round(final_score),round(score_a),round(score_b),round(score_c),round(score_d),round(score_e)
