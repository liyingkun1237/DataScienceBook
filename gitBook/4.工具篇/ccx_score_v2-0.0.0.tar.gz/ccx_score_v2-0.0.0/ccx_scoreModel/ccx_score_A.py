#### 基础信息+学历


import flask
from flask import request
from flask import jsonify
import json
from ccx_scoreModel.edu_base_score import *

server = flask.Flask(__name__)


@server.route('/ccxModel_A', methods=['post'])
def ccxModel_A():
    try:

        json_data = json.loads(request.data.decode())
        apply_score, score_a, score_b, score_c, score_d, score_e = score_A_compute(json_data)  # 机器学习模型分

        return jsonify(
            {'apply_score': apply_score, 'model_a': score_a, 'model_b': score_b, 'model_c': score_c, 'model_d': score_d,
             'model_e': score_e })
    except Exception as e:
        return jsonify({"code": 500, "msg": "计算失败", "error_msg": str(e)})




if __name__ == '__main__':
    server.run(debug=True, host='0.0.0.0', port=1028)  # processes 为可支持并发量
