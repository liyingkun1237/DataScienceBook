from ccx_scoreModel.f_basevar import *
from ccx_scoreModel.other_score import other_score
from ccx_scoreModel.submodel_5 import *
from sklearn.externals import joblib
from ccx_scoreModel.log import ABS_log
import pickle
path = os.path.dirname(os.path.realpath(__file__))


with open('score_tran_pkl_v2/base_score_dict.pkl', 'rb') as f: basescore_dict = pickle.load(f)
with open('score_tran_pkl/basescore_final.pkl', 'rb') as f: basescore_final_dict = pickle.load(f)

@ABS_log('ccxscore4')
def score_D_compute(json_data):
    df = pd.DataFrame(index=['id'])
    mob = json_data['mobile']
    cid = json_data['cid']
    df['age'] = f_age(cid)  # 年龄
    df['gender'] = f_gender(cid)  # 性别
    df['issame_prov'] = f_2equal_addr(f_get_mobile_prov(mob), get_idno_prov(cid))  # 省份是否一致
    df['issame_city'] = f_2equal_addr(f_get_mobile_city(mob), get_idno_city(cid))  # 城市是否一致

    '''
    mob_list = ['mob_3_134', 'mob_3_135', 'mob_3_136', 'mob_3_137', 'mob_3_138',
                'mob_3_139', 'mob_3_147', 'mob_3_150', 'mob_3_151', 'mob_3_152',
                'mob_3_157', 'mob_3_158', 'mob_3_159', 'mob_3_178', 'mob_3_182',
                'mob_3_183', 'mob_3_184', 'mob_3_187', 'mob_3_188']
    mob_var = 'mob_3_' + str(mob)[:3]

    for i in mob_list:
        df[i] = 0
    if mob_var in mob_list:
        df[mob_var] = 1
        
    '''
    #### 加载模型
    model_path = os.path.join(path, 'base_model.model')
    xgb_model = joblib.load(model_path)

    df3 = df[['age', 'gender', 'issame_prov', 'issame_city']]

    odd = list(map(lambda i: i / (1 - i), xgb_model.predict_proba(df3)[:, 1]))
    score_test = 600 - 40 / np.log(2) * np.log(odd[0])

    final_score = other_score(score_test,json_data,basescore_dict,basescore_final_dict)
    score_a = sub_basescore(score_test)
    score_b = sub_lvyuescore(json_data)
    score_c = sub_credit_score(json_data)
    score_d = sub_act_score(json_data)
    score_e = sub_soc_score(score_test, json_data)
    return round(final_score), round(score_a), round(score_b), round(score_c), round(score_d), round(score_e)
