#### 基础信息+学历

import flask
from flask import request
from flask import jsonify
import json
from ccx_scoreModel.edu_base_score import score_A_compute
from ccx_scoreModel.edu_ecomm_score import score_B_compute
from ccx_scoreModel.basevar_ecomm import score_C_compute
from ccx_scoreModel.basevar_model import score_D_compute
import pandas as pd

server = flask.Flask(__name__)

# 基础数据+学历
@server.route('/ccxModel_A', methods=['post'])
def ccxModel_A():
    try:
        json_data = json.loads(request.data.decode())
        apply_score, score_a, score_b, score_c, score_d, score_e = score_A_compute(json_data)  # 机器学习模型分
        return jsonify(
            {'apply_score': apply_score, 'model_a': score_a, 'model_b': score_b, 'model_c': score_c, 'model_d': score_d,
             'model_e': score_e })
    except Exception as e:
        return jsonify({"code": 500, "msg": "计算失败", "error_msg": str(e)})

#### 电商+学历+基础信息
@server.route('/ccxModel_B', methods=['post'])
def ccxModel_B():
    try:
        json_data = json.loads(request.data.decode())
        apply_score, score_a, score_b, score_c, score_d, score_e = score_B_compute(json_data)
        return jsonify(
            {'apply_score': apply_score, 'model_a': score_a, 'model_b': score_b, 'model_c': score_c, 'model_d': score_d,
             'model_e': score_e})

    except Exception as e:
        return jsonify({"code": 500, "msg": "计算失败", "error_msg": str(e)})

### 基础数据+电商
@server.route('/ccxModel_C', methods=['post'])
def ccxModel_C():
    try:
        json_data = json.loads(request.data.decode())
        apply_score, score_a, score_b, score_c, score_d, score_e = score_C_compute(json_data)
        return jsonify(
            {'apply_score': apply_score, 'model_a': score_a, 'model_b': score_b, 'model_c': score_c, 'model_d': score_d,
             'model_e': score_e})
    except Exception as e:
        return jsonify({"code": 500, "msg": "计算失败", "error_msg": str(e)})

### 基础数据
@server.route('/ccxModel_D', methods=['post'])
def ccxModel_D():
    try:
        json_data = json.loads(request.data.decode())
        apply_score, score_a, score_b, score_c, score_d, score_e = score_D_compute(json_data)
        return jsonify(
                    {'apply_score': apply_score, 'model_a': score_a, 'model_b': score_b, 'model_c': score_c, 'model_d': score_d,
                     'model_e': score_e})
    except Exception as e:
        return jsonify({"code": 500, "msg": "计算失败", "error_msg": str(e)})


if __name__ == '__main__':
    # server.run(debug=True, host='0.0.0.0', port=1024)  # processes 为可支持并发量
    server.run(debug=False, host='0.0.0.0', port=1024, processes = 4)  # processes 为可支持并发量








