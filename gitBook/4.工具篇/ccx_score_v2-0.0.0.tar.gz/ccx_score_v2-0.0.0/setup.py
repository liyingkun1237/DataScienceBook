from setuptools import setup

setup(
    name='ccx_score_v2',
    version='',
    packages=['ccx_scoreModel'],
    url='',
    license='2018-03-28',
    author='wjj',
    author_email='wangjiujun@ccx.cn',
    description='',
    package_data={'': ['*.py', '*.csv', '*.model', '*.pkl', '*.npy', '*/*.py', '*/*.pkl', '*/*.csv']},
    data_files=[('', ['setup.py'])]
)
